/*
   fontx2bdf.c - convert a single- or double-byte DOS FONTX2 font to BDF.

   Version: 1.1.

   Synopsis: fontx2bdf input_filename output_filename


   Author: Paul Hardy, unifoundry <at> unifoundry.com, April 2020
   
   Copyright (C) 2020 Paul Hardy

   LICENSE:

      This program is free software: you can redistribute it and/or modify
      it under the terms of the GNU General Public License as published by
      the Free Software Foundation, either version 2 of the License, or
      (at your option) any later version.

      This program is distributed in the hope that it will be useful,
      but WITHOUT ANY WARRANTY; without even the implied warranty of
      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
      GNU General Public License for more details.

      You should have received a copy of the GNU General Public License
      along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jisx2uni.h"

#define FONTX2BDF_VERSION "1.1"

#define DEVICE_DPI 96  /* To calculate SWIDTH parameter in BDF font */
#define BDF_X_DISPLACEMENT  0  /* BDF font parameter */
#define BDF_Y_DISPLACEMENT -2  /* BDF font parameter */

/* Uncomment the line below to get debug output */
// #define DEBUG

int
main (int argc, char *argv[]) {

   long filesize;        /* size of the file, in bytes           */
   int  inchars;         /* number of glyphs in input file       */
   int  outchars;        /* number of glyphs in output file      */
   char header[17];      /* the initial 17-byte FONTX2 header    */
   int  header_length;   /* return value from reading header     */
   char font_name[9];    /* name of this font, from FONTX2 file  */
   int  glyph_width;     /* pixel width of this font             */
   int  glyph_height;    /* pixel height of this font            */
   int  code_flag;       /* 0: 256-glyph font; 1: Shift-JIS font */
   int  i, j, k;         /* loop variables                       */
   int  row_bytes;       /* bytes in one row of a glyph          */
   int  glyph_bytes;     /* bytes in one glyph                   */
   int  point_size;      /* font point size, for BDF file        */
   int  swidth;          /* for BDF SWIDTH parameter             */
   int  jrow, jcell;     /* temporary row/cell pair              */
   int  jplane;          /* Shift-JIS plane of current glyph     */
   int  plane, row, cell; /* Shift-JIS plane, row, cell triplet  */
   int  file_loc;         /* current byte offset in input file   */

   /*
      Variables for Shift-JIS fonts (more than 256 glyphs).
   */
   int  n_blocks;     /* number of glyph blocks in the file          */
   int *start_byte1;    /* file offset of start of current block     */
   int *start_byte2;   /* file offset of end of current block        */
   int *end_byte1;      /* file offset of start of current block     */
   int *end_byte2;     /* file offset of end of current block        */
   int  block_num;    /* the current glyph block being processed     */
   int  byte1, byte2;       /* first and second byte of FONTX pair   */
   int  byte1a, byte2a;  /* pending 1st & 2nd byte pair, for looping */
   int  code_point;   /* Unicode code point for current glyph        */
   int  valid_code;   /* return value of shift_jis2prc()                 */

   /*
      Array to store pointers into FONTX2 file, so glyphs can be
      output in ascending according to Unicode code point.
   */
   int glyph_loc [0x10000];
   /*
      Structure to store the Shift-JIS plane, row, cell triplet
      that was mapped to each Unicode code point.
   */
   struct {
      unsigned char plane, row, cell;
   }  prc [0x10000];


   /*
      The input and output files.
   */
   FILE *infile;
   FILE *outfile;

   /* Increments input plane, row, cell to next value in order. */
   void next_pair (int inbyte1, int inbyte2, int *outbyte1, int *outbyte2);

   /* outputs one glyph description to BDF file. */
   void output_char (FILE *infile, FILE *outfile,
                     unsigned code_point, int plane, int row, int cell,
                     int row_bytes,
                     int glyph_width, int glyph_height, int swidth);

   /*
      Maps two FONTX2 bytes in a byte pair into
      a Shift-JIS plane, row, and cell triplet.
   */
   int shift_jis2prc (int byte1, int byte2, int *plane, int *row, int *cell);

   int    fseek  (FILE *stream, long offset, int whence);
   long   ftell  (FILE *stream);
   void   rewind (FILE *stream);
   size_t fread  (void *, size_t, size_t, FILE *);
   void  *calloc (size_t count, size_t size);


   /*
      Check that input file exists and output file does not exist.
   */

   if (argc < 2) {
      fprintf (stderr, "fontx2bdf version %s.\n\n", FONTX2BDF_VERSION);
      fprintf (stderr, "Usage:\n\n");
      fprintf (stderr, "     fontx2bdf input_file output_file\n\n");
      exit (EXIT_FAILURE);
   }

   /* Make sure output file doesn't exist so it isn't clobbered. */
   if ((outfile = fopen (argv[2], "r")) != NULL) {
      fclose (outfile);
      fprintf (stderr, "\nError: output file %s exists.\n", argv[2]);
      fprintf (stderr, "Please remove it.\n\n");
      fprintf (stderr, "Usage: fontx2bdf input_file output_file\n\n");
      exit (EXIT_FAILURE);
   }
  
   /* Make sure input file exists. */
   if ((infile = fopen (argv[1], "r")) == NULL) {
      fclose (infile);
      fprintf (stderr, "Error: input file %s does not exist.\n\n", argv[1]);
      fprintf (stderr, "Usage: fontx2bdf input_file output_file\n\n");
      exit (EXIT_FAILURE);
   }
  
   /* Get length of file to determine how many characters it contains. */
   (void)fseek (infile, 0L, SEEK_END);
   filesize = ftell (infile);
   if (filesize < 17) {
      fprintf (stderr, "Invalid file format; only %ld bytes in file.\n",
               filesize);
      exit (EXIT_FAILURE);
   }
  
   rewind (infile);

#ifdef DEBUG
   fprintf (stdout, "File length is %ld bytes.\n", filesize);
#endif

   /*
      Read the header.  A FONTX2 header is 17 bytes long.
   */
   header_length = fread (header, 1, 17, infile);
   file_loc = 17;  /* Point to current location in file. */

   if (strncmp (header, "FONTX2", 6) != 0) {
      fprintf (stderr,
               "Invalid FONTX2 header; file doesn't start with \"FONTX2\".\n");
      exit (EXIT_FAILURE);
   }


   /*
      Made it through basic sanity checks.  Now parse the font!
   */
   for (i = 0; i < 0x10000; i++) glyph_loc [i] = -1;  /* mark as unassigned */

   strncpy (font_name, &header [6], 8);
   font_name [8] = '\0';
   for (i = 7; i > 0 && font_name [i] == ' '; i--) font_name [i] = '\0';
   for ( ; i >= 0; i--) if (font_name [i] == ' ') font_name [i] = '_';

   glyph_width  = header [14];
   glyph_height = header [15];
   code_flag    = header [16];

   /*
      Calculate bytes per glyph row and bytes per glyph
      for stepping through the glyph bitmaps one at a time.
   */
   row_bytes  = (glyph_width + 7) / 8;
   glyph_bytes = row_bytes * glyph_height;

   /*
      Calculate BDF parameters point size and SWIDTH.
   */
   point_size = (72 * glyph_height + DEVICE_DPI - 1) / DEVICE_DPI;
   swidth     = glyph_width * 1000 * 72 / (point_size * DEVICE_DPI);

   /*
      Calculate the number of character glyphs in the input file.
   */
   if (code_flag == 0) {  /* max 256 glyphs in JIS X 0201 file */
      inchars = (filesize - 17) / glyph_bytes;
      /*
         Calculate the number of valid characters we'll output.
      */
      outchars = 0;  /* start with # of output glyphs is 0 */
      for (i = 0; i < inchars; i++) {  /* for each input character */
         code_point = fontx2uni [i];   /* get Unicode code point   */
         if (code_point >= 0 && code_point < 0x10000) {  /* Unicode Plane 0? */
            /* We're already at the right file location: byte 17 */
            /* If glyph_loc [code_point] != -1, it's already assigned */
            if (glyph_loc [code_point] != -1) {
               fprintf (stderr,
                  "Warning: duplicate code point mapping for byte %02X\n", i);
            }
            else {
               outchars++;  /* found one more glyph for BDF file */
            }
            /* store glyph offset in input file */
            glyph_loc [code_point] = file_loc;

#ifdef DEBUG
            fprintf (stdout, "Code Point %d: U+%04X\n", outchars, code_point);
#endif

         }
         file_loc += glyph_bytes;  /* point to start of next glyph bitmap */
      }
   }  /* code_flag == 0 */

   else {  /* this is a Shift-JIS font file with two bytes per code point */
      /* Read number of code blocks in file, in next input byte */
      n_blocks = fgetc (infile) & 0xFF;
      /* Calculate number of glyph bitmaps in the file */
      inchars = (filesize - 18 - 4 * n_blocks) / glyph_bytes;
      outchars = 0;  /* Increment this below for each valid output glyph */

#ifdef DEBUG
      fprintf (stdout, "Bytes per glyph: %d\n", glyph_bytes);
      fprintf (stdout, "Character Blocks: %d\n", n_blocks);
      fprintf (stdout, "Characters: %d\n", inchars);
#endif

      /* Allocate memory for code block endpoints */
      start_byte1 = calloc (n_blocks, sizeof (int));
      start_byte2 = calloc (n_blocks, sizeof (int));
      end_byte1   = calloc (n_blocks, sizeof (int));
      end_byte2   = calloc (n_blocks, sizeof (int));

      if (start_byte1 == NULL || start_byte2 == NULL ||
          end_byte1   == NULL || end_byte2   == NULL) {
         fprintf (stderr, "\nError: out of memory.\n\n");
         exit (EXIT_FAILURE);
      }

      /*
         Store all code block byte pair values.
         They're little-endian, so read 2 bytes reversed.
      */
      for (i = 0; i < n_blocks; i++) {
         start_byte2 [i] = fgetc (infile) & 0xFF;
         start_byte1 [i] = fgetc (infile) & 0xFF;
         end_byte2   [i] = fgetc (infile) & 0xFF;
         end_byte1   [i] = fgetc (infile) & 0xFF;
      }

      /*
         Advance byte count past Code Block section that
         we just read after the 17-byte initial file header.
      */
      file_loc += 1 + 4 * n_blocks;  /* Point to first glyph location. */

      /*
         Now infile points to the start of the glyphs.
      */
      for (i = 0; i < n_blocks; i++) {

#ifdef DEBUG
         fprintf (stdout, "Mapping %02X-%02X to %02X-%02X:\n",
                  start_byte1 [i], start_byte2 [i],
                  end_byte1   [i], end_byte2   [i]);
#endif
         byte1 = start_byte1 [i] & 0xFF;
         byte2 = start_byte2 [i] & 0xFF;
         do {

            valid_code =
               shift_jis2prc (byte1, byte2, &jplane, &jrow, &jcell);

#ifdef DEBUG
            fprintf (stdout, "   %02X-%02X @ 0x%06X",
                     byte1, byte2, file_loc);

            if (valid_code < 0) {
               fprintf (stdout, " (INVALID)");
            }
#endif

            /*
               If valid byte pair, convert to Shift-JIS
               plane, row, cell triplet to look up Unicode
               code points in the appropriate arrays.
            */
            if (valid_code >= 0) {

#ifdef DEBUG
               fprintf (stdout, " ==> %d-%02d-%02d", jplane, jrow, jcell);
#endif
               if (jplane == 1)
                  code_point = jisxp1 [jrow-1][jcell-1];
               else /* jplane == 2 */
                  code_point = jisxp2 [jrow-1][jcell-1];

               /* If valid code point, save glyph offset */
               if (code_point > 0 && code_point < 0x10000) {
                  /* See if this code point was previously mapped */
                  if (glyph_loc [code_point] != -1) {
                     fprintf (stderr,
                        "Warning: duplicate code point mapping for byte %02X\n", i);
                  }
                  else {
                     outchars++;  /* found a new glyph mapping for BDF file */
                  }

                  /* Point to glyph offset in input file. */
                  glyph_loc [code_point] = file_loc;

                  /*
                     Store the Shift-JIS plane, row, cell triplet
                     to print in BDF file's STARTCHAR string.
                  */
                  prc [code_point].plane = jplane;
                  prc [code_point].row   = jrow;
                  prc [code_point].cell  = jcell;

#ifdef DEBUG
                  fprintf (stdout, " ==> U+%04X @ 0x%06X",
                           code_point, glyph_loc [code_point]);
#endif

               }  /* valid code point, so store glyph offset */

#ifdef DEBUG
               else {  /* Code point is in Unicode Plane 2; doesn't map to BDF Plane 0 */
                  fprintf (stdout, " ==> U+%05X (skipped)", code_point);
               }
#endif

            }  /* valid byte pair (e.g., byte2 != 0x7F) */

#ifdef DEBUG
            fputc ('\n', stdout);
#endif

            file_loc += glyph_bytes;  /* Advance offset to next glyph bitmap */

            /* map 2-byte FONTX2 pair to next in series */
            next_pair (byte1, byte2, &byte1a, &byte2a);

            /* save next values for the next loop iteration */
            byte1 = byte1a;
            byte2 = byte2a;

         }  while (((    byte1     << 8) |     byte2) <=
                   ((end_byte1 [i] << 8) | end_byte2 [i]));

      }  /* for each FONTX2 code block */
   }  /* font uses two-byte Shift-JIS glyph bitmaps */

#ifdef DEBUG
   fprintf (stdout, "Font Name: %s\n", font_name);
   fprintf (stdout, "Width = %d, Height = %d, Code Flag = %d\n",
            glyph_width, glyph_height, code_flag);
   fprintf (stdout, "Bytes per glyph row: %d.\n", row_bytes);
   fprintf (stdout, "Total glyphs: %d.\n", inchars);
   fprintf (stdout, "Output glyphs: %d.\n", outchars);
   fprintf (stdout, "Point Size = %d at %d DPI\n", point_size, DEVICE_DPI);
   fprintf (stdout, "SWIDTH: %d.\n", swidth);
   fprintf (stdout, "Reading %d byte(s) per row, %d bytes per glyph.\n",
            row_bytes, glyph_bytes);
#endif

   /*
      Initial checks look okay.  Open output file to write BDF font.
   */
   if ((outfile = fopen (argv[2], "w")) == NULL) {
      fclose (infile);
      fprintf (stderr, "Error: cannot open file %s for output.\n\n", argv[2]);
      fprintf (stderr, "Usage: fontx2bdf input_file output_file\n\n");
      exit (EXIT_FAILURE);
   }


   /*
       Write the BDF font file.
   */

   fprintf (outfile, "STARTFONT 2.1\n");

   if (code_flag == 0) {
      fprintf (outfile, "COMMENT Unicode from FONTX2 JIS X 0201 font\n");
   }
   else {
      fprintf (outfile, "COMMENT Unicode from FONTX2 Shift-JIS font\n");
   }

   fprintf (outfile, "FONT %s\n", font_name);
   fprintf (outfile, "SIZE %d %d %d\n", point_size, DEVICE_DPI, DEVICE_DPI);
   fprintf (outfile, "FONTBOUNDINGBOX %d %d %d %d\n",
            glyph_width, glyph_height,
            BDF_X_DISPLACEMENT, BDF_Y_DISPLACEMENT);

   fprintf (outfile, "CHARS %d\n", outchars);


   /*
      Output glyphs in ascending order by Unicode code point.
   */

   if (code_flag == 0) {  /* input file is a 256-glyph FONTX2 font */
      /* For each Unicode Plane 0 code point in ascending order */
      for (i = 0; i < 0x10000; i++) {
         if (glyph_loc [i] > 0) {  /* Valid glyph is in file; output it */

            /* point to bitmap */
            fseek(infile, (long) glyph_loc [i], SEEK_SET);

            /* copy glyph bitmap to BDF output file, properly formatted */
            output_char (infile, outfile, i, -1, -1, -1,
                         row_bytes, glyph_width, glyph_height, swidth);

         }  /* glyph maps to a Unicode Plane 0 code point */
      }  /* for each code point in Unicode Plane 0 */
   }  /* code_flag == 0, non-Shift-JIS 256-glyph input font file */

   else {  /* input file is a JIS X 0208/0213 (Shift-JIS) font */
      /* For each Unicode Plane 0 code point in ascending order */
      for (i = 0; i < 0x10000; i++) {
         if (glyph_loc [i] > 0) {  /* Valid glyph is in file; output it */

            /* point to bitmap */
            fseek(infile, (long) glyph_loc [i], SEEK_SET);

            /* copy glyph bitmap to BDF output file, properly formatted */
            output_char (infile, outfile, i,
                         prc [i].plane, prc [i].row, prc [i].cell,
                         row_bytes, glyph_width, glyph_height, swidth);

         }  /* glyph maps to a Unicode Plane 0 code point */
      }  /* for each code point in Unicode Plane 0 */
   }  /* code_flag == 1, Shift-JIS input font file */


   /*
      Wrap up BDF file.
   */
   fprintf (outfile, "ENDFONT\n");

   /*
      All done!
   */
   fclose (outfile);
   fclose (infile);

   exit (EXIT_SUCCESS);
}


/*
   next_pair - take an input two-byte Shift-JIS pair and increment
               to the next two-byte pair.  Because a range in the
               input font file can span either side of the delete
               character (ASCII 0x7F), it is returned as a valid
               next value of the second byte.

               The ranges are:

                  Byte 1: 0x81..0x9F, 0xE0..0xFC
                  Byte 2: 0x40..0xFC

      Inputs:  inbyte1, inbyte2

      Outputs: outbyte1, outbyte2
*/
void
next_pair (int   inbyte1, int   inbyte2,
           int *outbyte1, int *outbyte2) {

   int newbyte1, newbyte2;

   newbyte1 = inbyte1;
   newbyte2 = inbyte2 + 1;
   if (newbyte2 > 0xFC) {
      newbyte2 = 0x40;
      newbyte1++;
      if (newbyte1 == 0xA0) {
         newbyte1 = 0xE0;
      }
      else if (newbyte1 > 0xFC) {
         newbyte1 = 0x81;
      }
   }

   *outbyte1 = newbyte1;
   *outbyte2 = newbyte2;

   return;
}


/*
   shift_jis2prc - read in first and second byte Shift-JIS values,
               and return Shift-JIS plane, row, and cell.

      Inputs:
               byte1 has valid ranges 0x81..0x9F, 0xE0..0xEF for Plane 1,
                                      0xF0..0xFC for Plane 2.

               byte2 has valid ranges 0x40..0x7E, 0x80..0xFC.


      Outputs:
               plane is 1 or 2.
               row ranges from 1..94.
               cell ranges from 1..94.

   Returns -1 if (byte1, byte2) pair was an invalid combination,
            0 if valid.

   If input byte pair was invalid, then plane, row, and cell are
   all set to -1 before returning as a further safeguard against
   misinterpretation of the result.
*/
int
shift_jis2prc (int byte1, int byte2, int *plane, int *row, int *cell) {

   int p2row;   /* Plane 2 row, from byte1 and byte2 values */
   int retval;  /* return value */

   retval = 0;  /* assume normal return */

   /*
      Determine cell number; adjust later if > 94.
   */
   *cell = shift_jisb2 [byte2];

   /*
      If in JIS X 0213 Plane 1 range
   */
   if (byte1 >= 0x81 && byte1 < 0xF0) {
      *plane = 1;
      *row   = shift_jisb1p1 [byte1];
      if (*cell > 94) {
         *row  +=  1;
         *cell -= 94;
      }
   }
   /*
      If in JIS X 0213 Plane 2 range, some rows
      are non-contiguous.
   */
   else if (byte1 >= 0xF0 && byte1 <= 0xFC) {
      /*
         Two entries per byte1 value: lower and upper half,
         so multiply byte1 by 2.
      */
      p2row  = (byte1 - 0xF0) << 1;
      if (*cell > 94) {
         p2row +=  1;
         *cell -= 94;
      }
      *row   = shift_jisb1p2 [p2row];
      *plane = 2;
   }
   else {  /* Invalid first byte value */
      *plane = *row = *cell = -1;
   }

   if (*plane == -1 || *row == -1 || *cell == -1) {
      *plane = *row = *cell = -1;
      retval = -1;  /* invalid byte pair for Shift-JIS conversion */
   }

   return retval;
}


/*
   Output the current glyph to the BDF file.

   All parameters are inputs:

      infile            input FONTX2 font file
      outfile           output BDF font file
      code_point        Unicode code point
      plane, row, cell  Shift-JIS plane, row, and cell, for STARTCHAR line
      row_bytes         number of bytes in one glyph row (output on one line)
      glyph_width       glyph width, in left-justified pixels
      glyph_height      glyph height, in pixels
      swidth            BDF scaled width parameter
*/
void
output_char (FILE *infile, FILE *outfile,
             unsigned code_point, int plane, int row, int cell,
             int row_bytes,
             int glyph_width, int glyph_height, int swidth) {

   int j, k;
   int next_byte;

   if (plane > 0) {  /* Shift-JIS character */
      fprintf (outfile, "STARTCHAR %d-%d-%d\n", plane, row, cell);
   }
   else {
      fprintf (outfile, "STARTCHAR U+%04X\n", code_point);
   }
   fprintf (outfile, "ENCODING %d\n", code_point);
   fprintf (outfile, "SWIDTH %d 0\n", swidth);
   fprintf (outfile, "DWIDTH %d 0\n", glyph_width);
   fprintf (outfile, "BBX %d %d %d %d\n",
            glyph_width, glyph_height,
            BDF_X_DISPLACEMENT, BDF_Y_DISPLACEMENT);

   fprintf (outfile, "BITMAP\n");
   for (j = 0; j < glyph_height; j++) { /* Print one bitmap row per line */
      for (k = 0; k < row_bytes; k++) {
         next_byte = fgetc (infile) & 0xFF;
         fprintf (outfile, "%02X", next_byte);
         fputc ('\n', outfile);
      }  /* end of row */
   }  /* end of character */
   fprintf (outfile, "ENDCHAR\n");

   return;
}

